<!doctype html>
<html lang ="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" 
    content="width=device-width,
     initial-scale=1"> 
     <!--titile of form-->      
     <title> Pizza Ordering Form</title>
     <meta name="description" content= "Creating form validation with php that enable users to order pizza">
     <meta name="robots"
     content="noindex,nofollow">
      <!--  fonts -->
    <link rel="preconnect"
     href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <!--  Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <!--   CSS file -->
     <link rel="stylesheet"type= "text/css"
     href="./css/style.css">
</head>
<body>
    <div class="myDiv">
        <img src="pizaa.jpg">
</div>
<div class="main menu">
     <ul>
     <li><a href="">Home</a></li>
     <li><a href="">About Us</a></li>
    <li><a href="">Contacts</a></li>
</ul>
</nav>
<section class= "Order Information">
    <p> Enter your information to proceed your order!</p>
 <?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
 // creating Variables
 $fname    = trim($_POST['fname']);
 $lname    = trim($_POST['lname']);
 $email    = trim($_POST['email']);
 $phonenumber = trim($_POST['phonenumber']);
$promocode = trim($_POST['promocode']);
 $address  = trim($_POST['address']);
    }
      ?>
       <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
          <p><input type="text" name="fname" placeholder="First Name"></p>
          <p><input type="text" name="lname" placeholder="Last Name"></p>
          <p><input type="email" name="email" placeholder="Email"></p>
          <p><input type="tel" name="phonenumber" placeholder="Phone number"></p>
          <p><input type="text" name="promocode" placeholder="Promo Code"></p>
          <p><input type="text" name="address" placeholder="Address"></p>
          <!-- Size Selection-->
          <p> Select Pizza Size</p>

          <input type="checkbox" id="sizeS" name="size[]" value=" Small ">
            <label for="sizeS">Small</label>
            <input type="checkbox" id="sizeM" name="size[]" value=" Medium ">
              <label for="sizeM">Medium</label>
              <input type="checkbox" id="sizeL" name="size[]" value=" Large ">
                <label for="sizeL">Large</label>
                <!--Select type of pizza-->
          <p>Order Now</p>

          <input type="checkbox" id="pizzaType1" name="pizza[]" value=" Chesse Pizza ">
            <label for="pizza1">Cheese Pizza</label>
          <input type="checkbox" id="pizzaType2" name="pizza[]" value=" Vegie loaded Pizza ">
            <label for="pizza2">Vegie loaded Pizza</label>
          <input type="checkbox" id="pizzaType3" name="pizza[]" value=" Butter Chicken Pizza ">
            <label for="pizza3"> Butter Chicken Pizza</label>
          <input type="checkbox" id="pizzaType4" name="pizza[]" value=" Pepperoni Pizza ">
            <label for="pizza4">Pepperoni Pizza</label>
<!-- Toppings-->
            <p>Toppings</p>

            <input type="checkbox" id="topping1" name="topping[]" value="Extra Cheese ">
              <label for="topping1">Extra Cheese </label>
            <input type="checkbox" id="topping2" name="topping[]" value=" Sweet corns">
              <label for="topping2">Sweet Corns</label>
            <input type="checkbox" id="topping3" name="topping[]" value="tomatoes ">
              <label for="topping3"> Tomatoes</label>
            <input type="checkbox" id="topping4" name="topping[]" value=" Mushrooms ">
              <label for="topping4">Mushrooms</label>
              <input type="checkbox" id="topping4" name="topping[]" value=" olives">
              <label for="topping5">Olives</label>
              <!--select payment option-->
              <p>Payment Option</p>

              <input type="checkbox" id="payment1" name="payment[]" value="Cash On Delivery ">
                    <label for="payment3">Cash On Delivery(Conditions implied) </label>
              <input type="checkbox" id="payment2" name="payment[]" value="Credit Card">
                <label for="payment1">Credit Card </label>
                <input type="checkbox" id="payment3" name="payment[]" value="Debit ">
                  <label for="payment2">Debit </label>


          <br>
          <input class="btn btn-primary order" type="Order Now" value="Order now">
          <input class="btn btn-dark cancel" type="Start over again" value="Start Again">
        </form>
        <section class="Final order">
          <h4>Order Information </h4>
          <p>Name: <?php echo "$fname $lname"; ?></p>
          <p>Email: <?php echo "$email"; ?></p>
          <p>Phone Number: <?php echo "$phonenumber"; ?></p>
          <p>promocode : <?php echo "$PromoCode"; ?></p>
          <p>Address: <?php echo "$address"; ?></p>
        </section>